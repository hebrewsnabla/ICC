void printmatdia(float **ma, int start, int end);
void printmatcol(float **ma, int col, int start, int end);
void printmat(float **ma, int z1, int s1, int z2, int s2);

